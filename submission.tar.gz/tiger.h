/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize 240x160 tiger tiger.jpeg 
 * Time-stamp: Wednesday 04/05/2023, 05:51:32
 * 
 * Image Information
 * -----------------
 * tiger.jpeg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TIGER_H
#define TIGER_H

extern const unsigned short tiger[38400];
#define TIGER_SIZE 76800
#define TIGER_LENGTH 38400
#define TIGER_WIDTH 240
#define TIGER_HEIGHT 160

#endif

