/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=40x40 finish2 finish2.jpeg 
 * Time-stamp: Wednesday 04/05/2023, 20:02:34
 * 
 * Image Information
 * -----------------
 * finish2.jpeg 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FINISH2_H
#define FINISH2_H

extern const unsigned short finish2[1600];
#define FINISH2_SIZE 3200
#define FINISH2_LENGTH 1600
#define FINISH2_WIDTH 40
#define FINISH2_HEIGHT 40

#endif

