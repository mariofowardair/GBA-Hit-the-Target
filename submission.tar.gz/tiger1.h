/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 tiger1 tiger1.jpeg 
 * Time-stamp: Thursday 04/06/2023, 00:00:54
 * 
 * Image Information
 * -----------------
 * tiger1.jpeg 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TIGER1_H
#define TIGER1_H

extern const unsigned short tiger1[900];
#define TIGER1_SIZE 1800
#define TIGER1_LENGTH 900
#define TIGER1_WIDTH 30
#define TIGER1_HEIGHT 30

#endif

