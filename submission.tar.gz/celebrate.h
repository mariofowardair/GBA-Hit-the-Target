/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 celebrate celebrate.jpg 
 * Time-stamp: Wednesday 04/05/2023, 18:43:40
 * 
 * Image Information
 * -----------------
 * celebrate.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CELEBRATE_H
#define CELEBRATE_H

extern const unsigned short celebrate[38400];
#define CELEBRATE_SIZE 76800
#define CELEBRATE_LENGTH 38400
#define CELEBRATE_WIDTH 240
#define CELEBRATE_HEIGHT 160

#endif

