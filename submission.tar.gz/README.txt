This is Avoid the Tiger!

Touch the finish line 3 times to win the game!
If you touch the Tiger, you lose!

Press Enter to Start the game
Press Backspace to reset the game
And use the arrow keys to move the person around!

Have Fun!