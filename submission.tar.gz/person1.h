/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 person1 person1.jpeg 
 * Time-stamp: Thursday 04/06/2023, 00:00:33
 * 
 * Image Information
 * -----------------
 * person1.jpeg 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PERSON1_H
#define PERSON1_H

extern const unsigned short person1[900];
#define PERSON1_SIZE 1800
#define PERSON1_LENGTH 900
#define PERSON1_WIDTH 30
#define PERSON1_HEIGHT 30

#endif

